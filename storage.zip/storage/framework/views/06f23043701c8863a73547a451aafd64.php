<div class="container-fluid container-xl position-relative d-flex align-items-center justify-content-between">

    <a href="/" class="logo d-flex align-items-center">
        <img src="<?php echo e(asset("assets/img/bgg_logo.jpg")); ?>" alt="" style="width: 100px; max-height:100px">
        <h1 class="sitename" style="font-size: 20px;">BGG ENTERTAINMENT</h1>
    </a>
    <nav id="navmenu" class="navmenu">
        <ul>
            <li>
                <a href="/" class="<?php echo e(request()->is('/') ? 'active' : ''); ?>">Home</a>
            </li>
            <li>
                <a href="<?php echo e(route('about_page')); ?>" class="<?php echo e(request()->is('about') ? 'active' : ''); ?>">About</a>
            </li>
            <li>
                <a href="<?php echo e(route('services_page')); ?>" class="<?php echo e(request()->is('services') ? 'active' : ''); ?>">Services</a>
            </li>
            <li>
                <a href="<?php echo e(route('contact_page')); ?>" class="<?php echo e(request()->is('contact') ? 'active' : ''); ?>">Contact</a>
            </li>
            <li>
                <a href="#">Blog</a>
            </li>
        </ul>
        <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
    </nav>

</div><?php /**PATH C:\wamp64\www\YHHM Company\BGG-website\resources\views/layouts/header.blade.php ENDPATH**/ ?>